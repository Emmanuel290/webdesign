  <nav class="navbar navbar-inverse" style="width: 81% !important; margin: auto;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="">CRUSAIDAL INSTITUTION</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="viewCandidate.php">Home</a></li>
      <li><a href=addCandidate.php>Add New participants</a></li>
      <li><a href="addQuestion.php">Add New Question</a></li>
      <li><a href="viewCandidate.php">View Candidates</a></li>
      <li><a href="viewQuestions.php">View Questions</a></li>
    </ul>
  </div>
</nav>
