<?php
  include_once ("inc/classes/session.php");
  include ("inc/classes/View.php");

  $userSession = new Session();
  if ($userSession->getSession('login') != true) {
    header('Location: login.php');
  }
  $userSession->destroy();

  $view = new View();
  $viewCandidates = $view->viewCandidate();
  //var_dump($viewCandidates);
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>View  perticipants</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  </head>
  <body>

<!------ Include the above in your HEAD tag ---------->

<div class="container">
<?php include ('nav.php'); ?>
    <div id="signupbox" style=" margin-top:10px" class="mainbox col-md-12  col-sm-8 ">
        <div class="panel panel-info">
            <div class="panel-heading">
                <div class="panel-title">View Candidates</div>

            </div>
            <div class="panel-body" >
              <table class="table table-bordered" style="width: 100%; table-layout: auto;">
                <thead>
                  <tr>
                    <th style="width: 15%;">perticipant Name</th>
                    <th style="width: 10%;">perticipant Email</th>
                    <th style="width: 5%;">Contact</th>
                    <th style="width: 30%;">perticipant Qualification</th>
                    <th style="width: 5%;">Age</th>
                    <th style="width: 25%;">Candidate Address</th>
                    <th style="width: 10%;">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($viewCandidates as $viewCandidate): ?>
                  <tr>
                    <td style="vertical-align: middle;"><?php echo $viewCandidate['cand_name']; ?></td>
                    <td style="vertical-align: middle;"><?php echo $viewCandidate['cand_email']; ?></td>
                    <td style="vertical-align: middle;"><?php echo $viewCandidate['cand_phone']; ?></td>
                    <td style="vertical-align: middle;"><?php echo $viewCandidate['cand_qualification']; ?></td>
                    <td style="vertical-align: middle;"><?php echo $viewCandidate['cand_age']; ?></td>
                    <td style="vertical-align: middle;"><?php echo $viewCandidate['cand_address']; ?></td>
                    <td style="vertical-align: middle;">
                      <a href="takeExam.php?id=<?php echo $viewCandidate['cand_id']; ?>" style="width: 100px;" class="btn btn-primary">Take Exam</a>
                      <a href="viewReport.php?id=<?php echo $viewCandidate['cand_id']; ?>" style="width: 100px; margin-top: 5px;" class="btn btn-success">View Report</a>
                      <a href="delete.php?action=deletecand&id=<?php echo $viewCandidate['cand_id']; ?>" style="width: 100px; margin-top: 5px;" class="btn btn-danger">Remove</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>

                </tbody>
              </table>
            </div>
        </div>
    </div>
</div>
</div>
<?php
 
$dataPoints = array(
	array("label"=> "DEGREE", "y"=> 2000),
	array("label"=> "DIPLOMA", "y"=> 1500),
	array("label"=> "MASTERS", "y"=> 150),

);
	
?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2", 
	title: {
		text: "CRUSAIDAL NUMBER OF QUALIFIED CANDIDATES 2019"
	},
	axisY: {
		title: "Number of candidates qualified so Far",
		includeZero: false
	},
	data: [{
		type: "column",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
  </body>
</html>

<p class="text-center top_spac"> <a href="?action=logout">Logout</a> </p>
